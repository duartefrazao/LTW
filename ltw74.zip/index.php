<?php
  header('Location: pages/posts.php');
?>